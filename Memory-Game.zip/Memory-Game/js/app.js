(function() {
    const arr = [
        "fa fa-heart",
        "fa fa-car",
        "fa fa-tree",
        "fa fa-plane",
        "fa fa-ship",
        "fa fa-apple",
        "fa fa-bicycle",
        "fa fa-book",
        "fa fa-heart",
        "fa fa-car",
        "fa fa-tree",
        "fa fa-plane",
        "fa fa-ship",
        "fa fa-apple",
        "fa fa-bicycle",
        "fa fa-book"
    ];

    let state = {};
    
    function shuffle(arr) {
        return [...arr].sort(() => 0.5 - Math.random());
    }
  
    function setCards() {
        state.heldCards = [];
        state.moves = 0;
        state.matchedCards = 0;
        state.timeFunc && clearInterval(state.timeFunc);
        state.seconds = -1;
        state.stars = 3;
        document.querySelector(".moves").textContent = "000";
        document.querySelector(".seconds").textContent = "000";
        let i;
        const cards = document.querySelectorAll(".card");
        for (i = 0; i < 16; i += 1) {
            cards[i].className = "card";
        }
        const starsEl = document.querySelectorAll(".stars i");
        starsEl.forEach((star) => (star.style.color = "gold"));

        const icons = document.querySelectorAll(".card > i");
        setTimeout(() => {
            shuffle(arr).forEach((element, index) => {
                icons[index].className = element;
            });
            document.querySelector(".deck").addEventListener("click", control);
            document
                .querySelector(".restart")
                .addEventListener("click", setCards, {once: true});
        }, 200);
    }

    function minusStar() {
        let starElement;
        if (state.stars === 3) {
            starElement = document.querySelectorAll(".stars i")[0];
        } else if (state.stars === 2) {
            starElement = document.querySelectorAll(".stars i")[1];
        }
        starElement.style.color = "black";
        state.stars -= 1;
    }

    function moveCounter() {
        state.moves += 1;
        let movesStr = String(state.moves);
        const moveElement = document.querySelector(".moves");
        moveElement.textContent = movesStr.padStart(3, "0");
    }
    /**
     * @param{boolean} tick
     */
    function myTimer(tick = true) {
        if (!tick) {
            clearInterval(state.timeFunc);
            return;
        }
        if (state.seconds === -1) {
            state.timeFunc = setInterval(myTimer, 1000);
        }
        state.seconds += 1;
        let secondsStr = String(state.seconds);
        document.querySelector(".seconds").textContent = secondsStr.padStart(
            3,
            "0"
        );
    }
    /**
     *
     * @param {object} e
     */
    function openCard(e) {
        e.target.className = "card open show";
    }
    /**
     * @param  {object} eventTarget
     * @return {string} icon
     */
    function getSymbol(eventTarget) {
        return eventTarget.querySelector("i").className;
    }
    /**
     * @return{boolean}
     */
    function checkCards() {
        return state.heldCards[0] === state.heldCards[2];
    }
    /**
     * @param  {string} icon
     * @param  {object} eventTarget
     */
    function holdCards(icon, eventTarget) {
        state.heldCards = [...state.heldCards, icon, eventTarget];
    }
   
    function matchCards() {
        state.heldCards[1].className = "card open match";
        state.heldCards[3].className = "card open match";
        state.heldCards = [];
        state.matchedCards += 1;
    }
   
    function closeCards() {
        setTimeout(function pause() {
            state.heldCards[1].className = "card";
            state.heldCards[3].className = "card";
            state.heldCards = [];
        }, 600);
    }

    function win() {
        document.querySelector(".deck").removeEventListener("click", control);
        myTimer(false);
      
        const modal = document.getElementById("myModal");

        const span = document.getElementsByClassName("close")[0];

        modal.style.display = "block";
  
        function displayNone() {
            modal.style.display = "none";
        }

        span.addEventListener("click", displayNone, {once: true});
        /**
         * @param {object} event
         */
        function windowClick(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }

        window.addEventListener("click", (e) => windowClick(e), {once: true});

        const movesModal = document.querySelector(".moves-modal");

        const secondsModal = document.querySelector(".seconds-modal");

        const starsModal = document.querySelector(".stars-modal");

        const startAgain = document.querySelector(".start-again");
        movesModal.textContent = state.moves;
        secondsModal.textContent = state.seconds;
        starsModal.textContent = state.stars;
     
        function restart() {
            modal.style.display = "none";
            setCards();
        }

        startAgain.addEventListener("click", restart, {once: true});
    }
    /**
     * @param  {object} e
     */
    function control(e) {
        const eventTarget = e.target;
        if (state.seconds === -1) {
            myTimer();
        }
        if (state.heldCards.length === 4) {
            return;
        }
        if (eventTarget && eventTarget.className === "card") {
            openCard(e);
        } else {
            return;
        }
        const icon = getSymbol(eventTarget);
        holdCards(icon, eventTarget);
        if (state.heldCards.length === 2) {
            return;
        }
        moveCounter();
        if (state.moves === 16 || state.moves === 32) {
            minusStar();
        }
        const match = checkCards();
        if (match) {
            matchCards();
        } else {
            closeCards();
            return;
        }
        if (state.matchedCards === 8) {
            win();
        }
    }

    setCards();
})();
