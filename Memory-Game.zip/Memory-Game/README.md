# Memory Game 

**Memory Game** is a card game that I had to create as part of building up my portfolio for the Front-End Web Developer Nanodegree Program.  
I proceeded by downloading the starter code that Udacity provided. This consisted of a HTML file, a CSS file, and a JavaScript file. I decided to introduce my own shuffle logic with the help provided by blog post on Udacity resources.  


## Dependency

For the modal box, I adapted an example from **w3schools**:

  * https://www.w3schools.com/howto/howto_css_modals.asp


## Instructions

The game consists of sixteen "cards" arranged in a grid of 4*4. The deck is made up of eight different pairs of cards, each with different symbols on one side. The symbols used are: (i) heart, (ii) car, (iii) tree, (iv) plane, (v) ship; (vi) apple, (vii) bicycle and (viii) book. The cards are randomly shuffled on the grid with the symbol face down. 

The rules of the game are that two cards can be flipped at one time and the aim is to identify the matching symbol. The user should click on one of the cards which are faced down and turn it over to check the symbol. The first time the face down card is flipped to reflect the symbol, it will be shown in colour - #02e4be and if the two matching symbols correspond then it will be change to colour #02cc4f. Therefore, if the cards match, their colour will change from #02e4be to #02cc4f. If the cards do not match, they will briefly flip and turn back to "face down".

Above the deck the following is displayed:

  * the number of moves the user has made so far
  * the number of seconds that have passed
  * the numbers of stars currently active
  * a reset button

  After a certain number of moves, the number of stars is reduced. *** stars is the highest available, * star is the lowest.

At the end, when all the cards are matched and the game is complete, the modal box pops up and the user is informed of:

  * how many moves they made
  * how many seconds it took
  * how many stars they achieved

The user also has the option to click on the "Start Again?" button if he wishes to play again.  

Here is the live version.
